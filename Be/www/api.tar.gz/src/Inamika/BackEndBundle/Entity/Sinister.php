<?php

//
//  Created by Mauricio Ampuero <mdampuero@gmail.com> on 2019.
//  Copyright © 2019 Inamika S.A. All rights reserved.
//

namespace Inamika\BackEndBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use JMS\Serializer\Annotation\ExclusionPolicy;
use JMS\Serializer\Annotation\Expose;

/**
 * Sinister
 *
 * @ORM\Table(name="sinister")
 * @ORM\Entity(repositoryClass="Inamika\BackEndBundle\Repository\SinisterRepository")
 * @ORM\HasLifecycleCallbacks()
 * @UniqueEntity(fields={"number"}, repositoryMethod="getUniqueNotDeleted")
 * @ExclusionPolicy("all")
 */

class Sinister
{
    /**
     * @var string
     *
     * @ORM\Column(name="id", type="guid")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     * @Expose
     */
    private $id;

    /**
     * Many Sinister have one Productor. This is the owning side.
     * @Assert\NotBlank()
     * @ORM\ManyToOne(targetEntity="Productor")
     * @ORM\JoinColumn(name="productor_id", referencedColumnName="id")
     * @Expose
     */
    private $productor;

    /**
     * Many Sinister have one Company. This is the owning side.
     * @Assert\NotBlank()
     * @ORM\ManyToOne(targetEntity="Company")
     * @ORM\JoinColumn(name="company_id", referencedColumnName="id")
     * @Expose
     */
    private $company;
    
    /**
     * Many Sinister have one Productor. This is the owning side.
     * @ORM\ManyToOne(targetEntity="SinisterStatus")
     * @ORM\JoinColumn(name="status_id", referencedColumnName="id")
     * @Expose
     */
    private $status;

    /**
     * @var string
     *
     * @ORM\Column(name="number", type="string", length=64)
     * @Assert\NotBlank()
     * @Assert\Length(
     *      min = 3,
     *      max = 32
     * )
     * @Expose
     */
    private $number;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="date")
     * @Assert\NotBlank()
     */
    private $date;

    /**
     * @var float
     *
     * @ORM\Column(name="amount", type="float")
     * @Assert\NotBlank()
     * @Expose
     */
    private $amount;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255)
     * @Assert\NotBlank()
     * @Expose
     */
    private $name;
    
    /**
     * @var string
     *
     * @ORM\Column(name="document", type="string", length=255)
     * @Assert\NotBlank()
     * @Expose
     */
    private $document;
    
    /**
     * @var string
     *
     * @ORM\Column(name="email", type="string", length=255)
     * @Assert\NotBlank()
     * @Assert\Email()
     * @Expose
     */
    private $email;

    /**
     * @var string
     *
     * @ORM\Column(name="phone", type="string", length=255)
     * @Assert\NotBlank()
     * @Expose
     */
    private $phone;
    
    /**
     * @var string
     *
     * @ORM\Column(name="provence", type="string", length=255)
     * @Assert\NotBlank()
     * @Expose
     */
    private $provence;
    
    /**
     * @var string
     *
     * @ORM\Column(name="city", type="string", length=255)
     * @Assert\NotBlank()
     * @Expose
     */
    private $city;
    
    /**
     * @var string
     *
     * @ORM\Column(name="street", type="string", length=255)
     * @Assert\NotBlank()
     * @Expose
     */
    private $street;
    
    /**
     * @var string
     *
     * @ORM\Column(name="department", type="string", length=255)
     * @Assert\NotBlank()
     * @Expose
     */
    private $department;
    
    /**
     * @var string
     *
     * @ORM\Column(name="floor", type="string", length=255)
     * @Assert\NotBlank()
     * @Expose
     */
    private $floor;
    
    /**
     * @var string
     *
     * @ORM\Column(name="street_number", type="string", length=255)
     * @Assert\NotBlank()
     * @Expose
     */
    private $streetNumber;

    /**
     * @var string|null
     *
     * @ORM\Column(name="observations", type="text", nullable=true)
     * @Expose
     */
    private $observations;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime")
     */
    private $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime")
     */
    private $updatedAt;

    /**
     * @var bool
     *
     * @ORM\Column(name="is_delete", type="boolean")
     * @Expose
     */
    private $isDelete=false;


    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set number.
     *
     * @param string $number
     *
     * @return Sinister
     */
    public function setNumber($number)
    {
        $this->number = $number;

        return $this;
    }

    /**
     * Get number.
     *
     * @return string
     */
    public function getNumber()
    {
        return $this->number;
    }
    
    /**
     * Set name.
     *
     * @param string $name
     *
     * @return Sinister
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name.
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }
    
    /**
     * Set document.
     *
     * @param string $document
     *
     * @return Sinister
     */
    public function setDocument($document)
    {
        $this->document = $document;

        return $this;
    }

    /**
     * Get document.
     *
     * @return string
     */
    public function getDocument()
    {
        return $this->document;
    }
    
    /**
     * Set phone.
     *
     * @param string $phone
     *
     * @return Sinister
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get phone.
     *
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }
    
    /**
     * Set provence.
     *
     * @param string $provence
     *
     * @return Sinister
     */
    public function setProvence($provence)
    {
        $this->provence = $provence;

        return $this;
    }

    /**
     * Get provence.
     *
     * @return string
     */
    public function getProvence()
    {
        return $this->provence;
    }
    
    /**
     * Set city.
     *
     * @param string $city
     *
     * @return Sinister
     */
    public function setCity($city)
    {
        $this->city = $city;

        return $this;
    }

    /**
     * Get city.
     *
     * @return string
     */
    public function getCity()
    {
        return $this->city;
    }
    
    /**
     * Set street.
     *
     * @param string $street
     *
     * @return Sinister
     */
    public function setStreet($street)
    {
        $this->street = $street;

        return $this;
    }

    /**
     * Get street.
     *
     * @return string
     */
    public function getStreet()
    {
        return $this->street;
    }
    
    /**
     * Set department.
     *
     * @param string $department
     *
     * @return Sinister
     */
    public function setDepartment($department)
    {
        $this->department = $department;

        return $this;
    }

    /**
     * Get department.
     *
     * @return string
     */
    public function getDepartment()
    {
        return $this->department;
    }
    
    /**
     * Set floor.
     *
     * @param string $floor
     *
     * @return Sinister
     */
    public function setFloor($floor)
    {
        $this->floor = $floor;

        return $this;
    }

    /**
     * Get floor.
     *
     * @return string
     */
    public function getFloor()
    {
        return $this->floor;
    }
    
    /**
     * Set streetNumber.
     *
     * @param string $streetNumber
     *
     * @return Sinister
     */
    public function setStreetNumber($streetNumber)
    {
        $this->streetNumber = $streetNumber;

        return $this;
    }

    /**
     * Get streetNumber.
     *
     * @return string
     */
    public function getStreetNumber()
    {
        return $this->streetNumber;
    }
    
    /**
     * Set email.
     *
     * @param string $email
     *
     * @return Sinister
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email.
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }
    
    /**
     * Set date.
     *
     * @param string $date
     *
     * @return Sinister
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date.
     *
     * @return string
     */
    public function getDate()
    {
        return $this->date;
    }
    
    /**
     * Set amount.
     *
     * @param string $amount
     *
     * @return Sinister
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;

        return $this;
    }

    /**
     * Get amount.
     *
     * @return string
     */
    public function getAmount()
    {
        return $this->amount;
    }
    
    /**
     * Set productor.
     *
     * @param string $productor
     *
     * @return Sinister
     */
    public function setProductor($productor)
    {
        $this->productor = $productor;

        return $this;
    }

    /**
     * Get productor.
     *
     * @return string
     */
    public function getProductor()
    {
        return $this->productor;
    }
    
    /**
     * Set company.
     *
     * @param string $company
     *
     * @return Sinister
     */
    public function setCompany($company)
    {
        $this->company = $company;

        return $this;
    }

    /**
     * Get company.
     *
     * @return string
     */
    public function getCompany()
    {
        return $this->company;
    }
    
    /**
     * Set status.
     *
     * @param string $status
     *
     * @return Sinister
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status.
     *
     * @return string
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set observations.
     *
     * @param string|null $observations
     *
     * @return Sinister
     */
    public function setObservations($observations = null)
    {
        $this->observations = $observations;

        return $this;
    }

    /**
     * Get observations.
     *
     * @return string|null
     */
    public function getObservations()
    {
        return $this->observations;
    }

    /**
     * Set createdAt.
     *
     * @param \DateTime $createdAt
     *
     * @return Sinister
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt.
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt.
     *
     * @param \DateTime $updatedAt
     *
     * @return Sinister
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt.
     *
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set isDelete.
     *
     * @param bool $isDelete
     *
     * @return Sinister
     */
    public function setIsDelete($isDelete)
    {
        $this->isDelete = $isDelete;

        return $this;
    }

    /**
     * Get isDelete.
     *
     * @return bool
     */
    public function getIsDelete()
    {
        return $this->isDelete;
    }

    /**
     * @ORM\PrePersist
     */
    public function setCreatedAtValue()
    {
        $this->createdAt=new \DateTime();
    }
    
    /**
     * @ORM\PrePersist
     * @ORM\PreUpdate
     */
    public function setUpdatedAtValue()
    {
        $this->updatedAt=new \DateTime();
    }
}
