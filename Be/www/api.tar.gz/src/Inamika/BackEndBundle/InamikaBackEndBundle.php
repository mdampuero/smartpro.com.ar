<?php

//
//  Created by Mauricio Ampuero <mdampuero@gmail.com> on 2019.
//  Copyright © 2019 Inamika S.A. All rights reserved.
//

namespace Inamika\BackEndBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class InamikaBackEndBundle extends Bundle
{
}
